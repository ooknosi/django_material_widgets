"""Django Material Widgets __init__ Configuration

"""
# pylint: disable=invalid-name

# https://docs.djangoproject.com/en/dev/ref/applications/#for-application-authors
default_app_config = 'material_widgets.apps.MaterialWidgetsConfig'
