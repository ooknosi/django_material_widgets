"""Django Material Widgets Tests __init__ Configuration
material_widgets/tests/__init__.py

"""
# pylint: disable=invalid-name

# https://docs.djangoproject.com/en/dev/ref/applications/#for-application-authors
default_app_config = 'material_widgets.tests.apps.MaterialWidgetsTestsConfig'
